/**************************************************************************
 *                           sudoku-serial.h                              *
 **************************************************************************                                                                   
 * Declaration of functions used in sudoku-serial.c                       *
 *************************************************************************/

#ifndef SUDOKU_SERIAL
#define SUDOKU_SERIAL

#include "board.h"

void bruteForce(Board *b);

#endif